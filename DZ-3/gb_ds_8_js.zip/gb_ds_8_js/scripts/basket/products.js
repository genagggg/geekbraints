'use strict';
const products = [
    new ProductDTO(
        0,
        '0.jpg',
        'Product 0',
        'Lorem ipsum dolor sit amet, consectured adition elit. Autnjb comdjfl ligh',
        52.22
    ),
    new ProductDTO(
        1,
        '1.jpg',
        'Product 1',
        'Lorem ipsum dolor sit amet, consectured adition elit. Autnjb comdjfl ligh',
        32.12
    ),
    new ProductDTO(
        2,
        '2.jpg',
        'Product 2',
        'Lorem ipsum dolor sit amet, consectured adition elit. Autnjb comdjfl ligh',
        52.22
    ),
    new ProductDTO(
        3,
        '3.jpg',
        'Product 3',
        'Lorem ipsum dolor sit amet, consectured adition elit. Autnjb comdjfl ligh',
        52.22
    ),
    new ProductDTO(
        4,
        '4.jpg',
        'Product 4',
        'Lorem ipsum dolor sit amet, consectured adition elit. Autnjb comdjfl ligh',
        52.22
    ),
    new ProductDTO(
        5,
        '5.jpg',
        'Product 5',
        'Lorem ipsum dolor sit amet, consectured adition elit. Autnjb comdjfl ligh',
        52.22
    ),

]